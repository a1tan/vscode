package com.akbank.identityhub.otpsms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtpsmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(OtpsmsApplication.class, args);
	}

}
